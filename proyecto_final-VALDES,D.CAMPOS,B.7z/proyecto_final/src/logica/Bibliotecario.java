package logica;

public class Bibliotecario extends Usuario{

	public Bibliotecario(int id,int CI, String nombre, String apellido, String mail, String password, TipoUsuario tipoUsuario) {

		super(id, CI, nombre, apellido, mail, password, tipoUsuario);
	}

}
